package com.uim.field.xmattersgtw;

import com.google.gson.Gson;
import com.nimsoft.nimbus.NimConfig;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.NimLog;
import com.nimsoft.nimbus.NimProbe;
import com.nimsoft.nimbus.NimSession;
import com.nimsoft.nimbus.PDS;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import java.text.SimpleDateFormat;

public class XMattersGtw
{
  private static NimLog logger = NimLog.getLogger(XMattersGtw.class.getName());
  private static final String PROBE_NAME = "xmattersgtw";
  private static final String PROBE_VERSION = "Version 1.14";
  private static final String PROBE_COMPANY = "CA Technologies";
  private static final String PROBE_CONFIG = "xmattersgtw.cfg";
  private static String xMattersURL;
  private static String xMattersUser;
  private static String xMattersPassword;
  private static NimConfig config;
  private NimProbe probe;
  
  /************
   * Versioning
   * Version	Author				Description of changes
   * 1.10		xMatters 			provides base JSON from UIM to destination URL
   * 1.11		Matt Steele			Recreated from original version where we didn't have source code
   * 1.12		Matt Steele			Added Source to the JSON package		
   * 1.13		Matt Steele			Added UserTag1 and UserTag2 to the JSON package, removed "defaultXXX" from set strings
   * 1.14		Matt Steele			Added Custom_1 - Custom_5
   ************/
  
  public XMattersGtw() {}
  
  public static void main(String[] args) throws NimException { XMattersGtw xmattersgtw = new XMattersGtw();
    try
    {
      xmattersgtw.run(args);
    } catch (NimException e) {
      logger.log(0, e.toString());
    }
  }
  
  public void run(String[] args) throws NimException
  {
    do
    {
      com.nimsoft.nimbus.NimEnv.setSystemPropertiesFromEnvironment();
      probe = new NimProbe(PROBE_NAME, PROBE_VERSION, PROBE_COMPANY, PROBE_CONFIG, args);
      

      config = NimConfig.getInstance();
      

      int logLevel = config.getValueAsInt("/setup", "loglevel", 1);
      NimLog.setLogLevel(logLevel);
      
      logger.log(0, " ----- Getting Config -----");
      

      xMattersURL = config.getValueAsString("/setup", "xmattersurl", "undefined");
      xMattersUser = config.getValueAsString("/setup", "xmattersuser", "undefined");
      xMattersPassword = config.getValueAsString("/setup", "xmatterspassword", "undefined");
      
      if ((xMattersURL.contentEquals("undefined")) || (xMattersUser.contentEquals("undefined")) || (xMattersPassword.contentEquals("undefined"))) {
        logger.log(0, "FATAL: xMattersURL, xMattersUser, and xMattersPassword must be set in the config file.");
      }
      

      if (xMattersPassword.contains("==")) {
        logger.log(0, "Found encrypted password in config. Decrypting.");
        xMattersPassword = config.getValueAsStringDecrypted("/setup", "xmatterspassword", "DANGERZONE");
      } else {
        logger.log(0, "Plain text password found, encrypting password");
        config.setValueEncryptedUTF8("/setup", "xmatterspassword", xMattersPassword, "DANGERZONE");
        config.save();
      }
      
      logger.log(0, "xMatters URL = " + xMattersURL);
      logger.log(0, "xMatters User= " + xMattersUser);
      logger.log(1, "xMatters Password = " + xMattersPassword);
      


      logger.log(0, "Registering callback");
      probe.setSubscribeSubject("xmatters");
      probe.registerHubpostCallback(this, "hubpostCallback");
      logger.log(0, "Callback registration complete");




    }
    while (probe.doForever());
    
    logger.log(0, " -----Probe Stopping----");
  }
  




  public static void hubpostCallback(NimSession session, PDS pdsdata, PDS pdsuserdata)
    throws NimException
  {
    logger.log(0, "[hubpost]Received an xMatters alarm request");
    

    XMattersAlarmTemplate xMattersAlarm = new XMattersAlarmTemplate();
    xMattersAlarm.setSubject(pdsdata.getString("subject", ""));
    xMattersAlarm.setAlarmSev(pdsuserdata.getString("severity", ""));
    xMattersAlarm.setHostname(pdsuserdata.getString("hostname", ""));
    xMattersAlarm.setSubsystem(pdsuserdata.getString("subsys", ""));
    xMattersAlarm.setRobot(pdsuserdata.getString("robot", ""));
    xMattersAlarm.setProbe(pdsuserdata.getString("prid", ""));
    xMattersAlarm.setMessage(pdsuserdata.getString("message", ""));
    xMattersAlarm.setAlarmCount(pdsuserdata.getString("suppcount", ""));
    xMattersAlarm.setAlarmID(pdsuserdata.getString("nimid", ""));
    xMattersAlarm.setAlarm_Source(pdsuserdata.getString("source", ""));
    xMattersAlarm.setUserTag1(pdsuserdata.getString("user_tag1", ""));
    xMattersAlarm.setUserTag2(pdsuserdata.getString("user_tag2", ""));
    xMattersAlarm.setCustom_1(pdsuserdata.getString("custom_1", ""));
    xMattersAlarm.setCustom_2(pdsuserdata.getString("custom_2", ""));
    xMattersAlarm.setCustom_3(pdsuserdata.getString("custom_3", ""));
    xMattersAlarm.setCustom_4(pdsuserdata.getString("custom_4", ""));
    xMattersAlarm.setCustom_5(pdsuserdata.getString("custom_5", ""));
    

    String timeArrived = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(Long.valueOf(pdsuserdata.getInt("arrival") * 1000L));
    xMattersAlarm.setTimeArrived(timeArrived);
    
    String timeReceived = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(Long.valueOf(pdsuserdata.getInt("nimts") * 1000L));
    xMattersAlarm.setTimeReceived(timeReceived);
    
    logger.log(0, "[hubpost] Alarm attributes: " + xMattersAlarm.getSubject() + " " + xMattersAlarm.getHostname() + " " + xMattersAlarm.getSubsystem() + " " + xMattersAlarm.getRobot() + " " + xMattersAlarm.getProbe() + " " + xMattersAlarm.getMessage() + " " + xMattersAlarm.getTimeReceived() + " " + xMattersAlarm.getTimeArrived() + " " + xMattersAlarm.getAlarmCount() + " " + xMattersAlarm.getAlarmID() + " " + xMattersAlarm.getAlarm_Source() + " " + xMattersAlarm.getUserTag1() + " " + xMattersAlarm.getUserTag2() + " " + xMattersAlarm.getCustom_1() + " " + xMattersAlarm.getCustom_2() + " " + xMattersAlarm.getCustom_3() + " " + xMattersAlarm.getCustom_4() + " " + xMattersAlarm.getCustom_5());
    

    logger.log(1, "[hubpost] Converting alarm to JSON");
    Gson xMattersGSON = new Gson();
    String xMattersJSON = xMattersGSON.toJson(xMattersAlarm);
    logger.log(1, "[hubpost] JSON conversion complete");
    
    xMattersJSON = "{ \"properties\":" + xMattersJSON + "}";
    
    logger.log(1, "[hubpost] xMatters JSON: " + xMattersJSON);
    

    logger.log(1, "[hubpost] Creating client browser");
    Client xMattersClient = Client.create();
    xMattersClient.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(xMattersUser, xMattersPassword));
    WebResource xMattersAPI = xMattersClient.resource(xMattersURL);
    logger.log(1, "[hubpost] Posting transaction to xMatters");
    ClientResponse xMattersResponse = (ClientResponse)xMattersAPI.type("application/json").post(ClientResponse.class, xMattersJSON);
    logger.log(1, "[hubpost] Post complete");
    

    String xMattersAlarmID = (String)xMattersResponse.getEntity(String.class);
    
    logger.log(0, "[hubpost] xMatters HTTP Response: " + xMattersResponse.getStatus());
    logger.log(1, "[hubpost] xMatters Response Text: " + xMattersAlarmID);
    


    xMattersAlarmID = xMattersAlarmID.substring(7, xMattersAlarmID.length() - 2);
    
    logger.log(0, "[hubpost] xMatters Alarm ID: " + xMattersAlarmID);
    logger.log(0, "[hubpost]Alarm processing complete");
    

    session.sendReply(0, null);
    logger.log(1, "[hubpost] Client browser destroyed. Waiting for new alarms.");
  }
}
