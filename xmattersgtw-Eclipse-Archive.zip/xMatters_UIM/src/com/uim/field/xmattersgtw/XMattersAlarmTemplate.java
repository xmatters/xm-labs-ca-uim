package com.uim.field.xmattersgtw;

public class XMattersAlarmTemplate { public XMattersAlarmTemplate() {}
  private String subject = "";
  private String alarmSev = "";
  private String hostname = "";
  private String subsystem = "";
  private String robot = "";
  private String probe = "";
  private String message = "";
  private String timeReceived = "";
  private String timeArrived = "";
  private String alarmCount = "";
  private String alarmID = "";
  private String alarm_source = "";
  private String UserTag1 = "";
  private String UserTag2 = "";
  private String Custom_1 = "";
  private String Custom_2 = "";
  private String Custom_3 = "";
  private String Custom_4 = "";
  private String Custom_5 = "";
  
  public String getSubject() {
    return subject;
  }
  
  public void setSubject(String subject) { this.subject = subject; }
  
  public String getAlarmSev() {
    return alarmSev;
  }
  
  public void setAlarmSev(String alarmSev) { this.alarmSev = alarmSev; }
  
  public String getHostname() {
    return hostname;
  }
  
  public void setHostname(String hostname) { this.hostname = hostname; }
  
  public String getSubsystem() {
    return subsystem;
  }
  
  public void setSubsystem(String subsystem) { this.subsystem = subsystem; }
  
  public String getRobot() {
    return robot;
  }
  
  public void setRobot(String robot) { this.robot = robot; }
  
  public String getProbe() {
    return probe;
  }
  
  public void setProbe(String probe) { this.probe = probe; }
  
  public String getMessage() {
    return message;
  }
  
  public void setMessage(String message) { this.message = message; }
  
  public String getTimeReceived() {
    return timeReceived;
  }
  
  public void setTimeReceived(String timeReceived) { this.timeReceived = timeReceived; }
  
  public String getTimeArrived() {
    return timeArrived;
  }
  
  public void setTimeArrived(String timeArrived) { this.timeArrived = timeArrived; }
  
  public String getAlarmCount() {
    return alarmCount;
  }
  
  public void setAlarmCount(String alarmCount) { this.alarmCount = alarmCount; }
  
  public String getAlarmID() {
    return alarmID;
  }
  
  public void setAlarmID(String alarmID) { this.alarmID = alarmID; }

  public String getAlarm_Source() {
	    return alarm_source;
	  }
	  
  public void setAlarm_Source(String alarm_source) { this.alarm_source = alarm_source; }
  
  public String getUserTag1() {
	    return UserTag1;
	  }
	  
  public void setUserTag1(String UserTag1) { this.UserTag1 = UserTag1; }
  
  public String getUserTag2() {
	    return UserTag2;
	  }
	  
  public void setUserTag2(String UserTag2) { this.UserTag2 = UserTag2; }
  
  public String getCustom_1() {
	    return Custom_1;
	  }
	  
  public void setCustom_1(String Custom_1) { this.Custom_1 = Custom_1; }
  
  public String getCustom_2() {
	    return Custom_2;
	  }
	  
  public void setCustom_2(String Custom_2) { this.Custom_2 = Custom_2; }
  
  public String getCustom_3() {
	    return Custom_3;
	  }
	  
  public void setCustom_3(String Custom_3) { this.Custom_3 = Custom_3; }
  
  public String getCustom_4() {
	    return Custom_4;
	  }
	  
  public void setCustom_4(String Custom_4) { this.Custom_4 = Custom_4; }
  
  public String getCustom_5() {
	    return Custom_5;
	  }
	  
  public void setCustom_5(String Custom_5) { this.Custom_5 = Custom_5; }

}
