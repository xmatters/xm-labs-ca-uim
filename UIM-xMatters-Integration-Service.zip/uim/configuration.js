// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// Callbacks requested for this integration service.
// ----------------------------------------------------------------------------------------------------
CALLBACKS = ["status", "response"];

// ----------------------------------------------------------------------------------------------------
// UIM Configurations
// ----------------------------------------------------------------------------------------------------

//Variables used for the call back to OIM in the api path 
UIM_PROTOCOL = "http";
UIM_SERVER = "amdc1pxm02";

//OIM user that can make Web Service Calls into OIM
UIM_USER = "xmatters";
UIM_PASSWORD = "password";
