load("integrationservices/applications/uim/configuration.js");
load("lib/integrationservices/javascript/event.js");


function apia_callback(msg)
{
    var str = "Received message from xMatters:\n";
    str += "Incident: " + msg.incident_id;
    str += "\nEvent Id: " + msg.eventidentifier;
    str += "\nCallback Type: " + msg.xmatters_callback_type;
    IALOG.info(str);

 try {
  
    switch (msg.xmatters_callback_type) {

      case "response":
       handleResponse(msg);
        break;
        
      case "status":
       handleEventStatus(msg);
        break;
      
    }
    
  } catch (e) {
    IALOG.error("apia_callback(" + msg.eventidentifier + ", " + msg.xmatters_callback_type + "): caught Exception - name: [" + e.name + "], message [" + e.message + "]: " + msg);

    throw e;
  }

}

function handleEventStatus(msg){

if (msg.status == "active"){

var emptyBody = "";
var eventID = "EventID: " +  msg.eventidentifier;
var uriStatus = encodeURI(eventID);
var URL_ASSIGN = UIM_PROTOCOL + "://" + UIM_SERVER + "/rest/alarms/" + msg.additionalTokens.alarmID + "/assign/" + uriStatus;

// FYI:
// XMIO.JS WAS CUSTOMIZED TO SUPPORT THE UIM PUT API 
// LINE 104, VAR = RESPONSE.... THE RESPONSE.BODY WILL NO LONGER RETURN FOR THE PUT METHOD
// THE UIM DOCUMENTATION STATES THAT NO BODY WILL RETURN. WITHOUT A CUSTOMIZATION  A NULL POINTER EXCEPTION WAS LOGGED.
XMIO.put(emptyBody, URL_ASSIGN,  UIM_USER, UIM_PASSWORD);
   }
}

function handleResponse(msg){

var emptyBody = "";
var recipientAndID = msg.recipient + " | EventID: " + msg.eventidentifier;  
var uriAssign = encodeURI(recipientAndID);
if (msg.response == "Accept"){
var URL_ASSIGN = UIM_PROTOCOL + "://" + UIM_SERVER + "/rest/alarms/" + msg.additionalTokens.alarmID + "/assign/" + uriAssign;
XMIO.put(emptyBody, URL_ASSIGN,  UIM_USER, UIM_PASSWORD); 
  }


if (msg.response == "Resolve"){
var URL_RESOLVE = UIM_PROTOCOL + "://" +  UIM_SERVER + "/rest/alarms/" + msg.additionalTokens.alarmID + "/ack";
XMIO.put(emptyBody, URL_RESOLVE,  UIM_USER, UIM_PASSWORD);
  }

}
